"""Marker library to detect whether urllib3 was installed with the deprecated [secure] extra."""

__version__ = "0.1.0"
